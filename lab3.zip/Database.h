#ifndef DATABASE
#define DATABASE
//CAN BE EMPY!!!!!
#include <iostream>
#include <string>
#include <cctype>
#include <fstream>
#include <vector>
#include <set>
#include <iterator>
#include <exception>
#include <map>

#include"Relation.h"

using namespace std;

class Database : public map<string, Relation> {

private:


public:


};


#endif
